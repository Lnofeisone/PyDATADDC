# pydata_dc
Fuzzy Search Talk at PyData DC 2016
